# creepMinerGUI

Requirements for compile:
npm

Installation:

npm install

npm start

For build:

npm run-scripts linux

npm run-scripts win

npm run-scripts mac (not tested!!)

Already build for linux/windows:

https://drive.google.com/drive/folders/0B-VO0irYuQ-_clMwRVlnZDlOYlE?usp=sharing


version 1.2.0

fixed resize issue

fixed real burst address in app header

fixed erasing mining.conf issue in 1st time setting of the field miner path

fixed values in chart

fixed burst address display issue

fixed refresh account details in realtime

added tray icon enable/disable functionality

added refresh button for the Wallet infos

added better bottom status bar messages

added log panel

added 1st time setup wizard

added mining.conf backup in 1st time run

added restore / backup button mining.conf from backup

added dont show up again / cancel in wizard

added sound alarm on new block

added hdd time delay until nonce found

added ws ip for remote connection option

added memory new window dimensions (width, height)

added notification popups in operating system

added preloader




